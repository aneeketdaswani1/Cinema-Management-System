package management.cinema.Dbconnection;

import java.sql.*;

public class NewClass {

    public Connection con;
    public Statement stmt;
    String url = "jdbc:mysql://localhost:3306/cinema_management_system?autoReconnect=true&useSSL=false";
    //String user = "root";
    //String password = "syed531";

    public NewClass() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url, "root", "syed531");
            stmt = con.createStatement();
            System.out.println("Success");
        } catch (Exception e) {
            e.printStackTrace();
        }
    } 
}
