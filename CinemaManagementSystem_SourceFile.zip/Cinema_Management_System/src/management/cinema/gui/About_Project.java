package management.cinema.gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

//Jframe that displays project version
public class About_Project extends JFrame {
    //swing components to be used
    private JLabel cinematext = new JLabel("Cinema Management System");
    private JLabel versiontext = new JLabel("V 1.0");
    private JLabel footnotetext = new JLabel("A Real World Java project for Cinema Management");
    private JButton exit_btn = new JButton();
    //
    About_Project() {
        
        setLayout(null); 
        setUndecorated(true); 
        setSize(650, 300);
        setLocation(400, 200);
        getContentPane().setBackground(Color.BLUE); 
        //
        cinematext.setBounds(130, 100, 400, 30);
        versiontext.setBounds(500, 100, 50, 20);
        exit_btn.setBackground(Color.LIGHT_GRAY);
        exit_btn.setForeground(Color.LIGHT_GRAY);
        exit_btn.setBounds(610, 0, 40, 40);
        footnotetext.setBounds(100, 150, 500, 30);
        cinematext.setFont(new Font("Calibri", Font.BOLD, 30));
        versiontext.setFont(new Font("Calibri", Font.BOLD, 10));
        footnotetext.setFont(new Font("Calibri", Font.BOLD, 20));
        cinematext.setForeground(Color.WHITE);
        versiontext.setForeground(Color.WHITE);
        footnotetext.setForeground(Color.WHITE);
        //
        add(cinematext);
        add(versiontext);
        add(footnotetext);
        add(exit_btn);
        exit_btn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent r) {
                setVisible(false);
            }
        });
        setVisible(true);
    }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable(){
            public void run() {
                new About_Project();
            }
        });
    }
}
