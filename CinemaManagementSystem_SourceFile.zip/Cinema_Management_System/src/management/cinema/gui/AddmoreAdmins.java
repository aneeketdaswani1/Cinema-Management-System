package management.cinema.gui;

import com.mysql.jdbc.PreparedStatement;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import management.cinema.Dbconnection.NewClass;

public class AddmoreAdmins extends JFrame {
    NewClass n = new NewClass();
    //
    JTextField txtusername = new JTextField();
    JPasswordField txtpassword = new JPasswordField();
    JLabel username_DisplayText = new JLabel("Username");
    JLabel password_Displaytext = new JLabel("Password");
    JButton SignUp = new JButton("Add User");
    JLabel MainTitle = new JLabel("Add More Admins");
    //
    public AddmoreAdmins() {
        setTitle("Add An Administrator"); 
        setLayout(null); 
        setResizable(false); 
        setLocation(400, 180);
        setSize(600, 400);
        getContentPane().setBackground(Color.LIGHT_GRAY);
        //
        MainTitle.setBounds(150, 30, 350, 50);
        txtusername.setBounds(250, 120, 200, 20);
        txtpassword.setBounds(250, 170, 200, 20);
        username_DisplayText.setBounds(120, 115, 150, 25);
        password_Displaytext.setBounds(120, 170, 150, 25);
        SignUp.setBounds(250, 250, 90, 70);
        //
        MainTitle.setFont(new Font("Calibri", Font.BOLD, 40) {});
        username_DisplayText.setFont(new Font("Arial", Font.BOLD, 15) {});
        password_Displaytext.setFont(new Font("Arial", Font.BOLD, 15) {  });
        SignUp.setBackground(Color.black);
        SignUp.setForeground(Color.white);
        //
        add(SignUp);
        add(txtusername);
        add(txtpassword);
        add(username_DisplayText);
        add(password_Displaytext);
        add(MainTitle);
        //
        SignUp.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                String a = txtusername.getText();
                String b = txtpassword.getText();
                try {
                    String Query = "INSERT INTO `login_cred`(`username`, `password`) VALUES (?,?)";
                    PreparedStatement pst = (PreparedStatement) n.con.prepareStatement(Query);
                    pst.setString(1, a);
                    pst.setString(2, b);
                    pst.executeUpdate();
                    JOptionPane.showMessageDialog(null, "Insertion Is Successful!");
                    n.con.close();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        });
        setVisible(true);
    }
    public static void main(String[] args) {
        new AddmoreAdmins();
    }   
}
