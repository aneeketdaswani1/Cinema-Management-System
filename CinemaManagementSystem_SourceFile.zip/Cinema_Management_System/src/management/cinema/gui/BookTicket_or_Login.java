/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package management.cinema.gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.logging.Level;
import java.util.logging.Logger;

public class BookTicket_or_Login extends JFrame {

    private JButton login_btn = new JButton("Login");
    private JButton IssueA_Ticket = new JButton("Book Ticket");
    private JLabel MainTitle = new JLabel("Choose An Option");
    //
    public BookTicket_or_Login() { 
        setLayout(null);
        setResizable(false);
        setLocation(450, 130);
        setSize(520, 360);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        getContentPane().setBackground(Color.ORANGE);
        //
        login_btn.setBounds(90, 130, 120, 80);
        IssueA_Ticket.setBounds(290, 130, 120, 80);
        MainTitle.setBounds(100, 20, 400, 60);
        //    
        login_btn.setBackground(Color.BLACK);
        login_btn.setForeground(Color.WHITE);
        IssueA_Ticket.setBackground(Color.BLACK);
        IssueA_Ticket.setForeground(Color.WHITE);
        MainTitle.setFont(new Font("Calibri", Font.PLAIN, 40));
        login_btn.setFont(new Font("Calibri", Font.PLAIN, 25));
        IssueA_Ticket.setFont(new Font("Calibri", Font.PLAIN, 18));
        //     
        add(login_btn);
        add(IssueA_Ticket);
        add(MainTitle);
        //
        setVisible(true);
        //Login control
        login_btn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent r) {
                setVisible(false);
                new CinemaEmployeeAuthentication().setVisible(true);
            }
        });
        //event of opening booking tickets
        IssueA_Ticket.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent t){
                setVisible(false);
                try {
                    new GiantCustomerWindowFrame().setVisible(true);
                } catch (Exception ex) {
                    Logger.getLogger(BookTicket_or_Login.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }//main class to call the constructor for the sake of running the Window panel in this class
    public static void main(String[] args) {
        new BookTicket_or_Login();
    }
}
