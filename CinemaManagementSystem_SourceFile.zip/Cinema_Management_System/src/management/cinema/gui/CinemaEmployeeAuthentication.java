package management.cinema.gui;

import com.mysql.jdbc.PreparedStatement;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import management.cinema.Dbconnection.NewClass;
import java.sql.ResultSet;

public class CinemaEmployeeAuthentication extends JFrame {

    JTextField txtusername = new JTextField();
    JPasswordField txtpassword = new JPasswordField();
    JLabel username_DisplayText = new JLabel("Username");
    JLabel password_Displaytext = new JLabel("Password");
    JButton LOGIN_BTN = new JButton("Login");
    JLabel MainTitle = new JLabel("Login To Continue");
    //
    String username;
    String password;
    PreparedStatement ps;
    ResultSet rest;
    //
    CinemaEmployeeAuthentication() {
        
        setTitle("Login to Continue");
        setLayout(null);
        setResizable(false);
        setLocation(400, 180);
        setSize(600, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        //
        MainTitle.setBounds(150, 30, 300, 50);
        txtusername.setBounds(250, 120, 200, 20);
        txtpassword.setBounds(250, 170, 200, 20);
        username_DisplayText.setBounds(120, 115, 150, 25);
        password_Displaytext.setBounds(120, 170, 150, 25);
        LOGIN_BTN.setBounds(250, 250, 90, 70);
        //
        MainTitle.setFont(new Font("Calibri", Font.BOLD, 40) {});
        username_DisplayText.setFont(new Font("Arial", Font.BOLD, 15) {});
        password_Displaytext.setFont(new Font("Arial", Font.BOLD, 15) {});
        LOGIN_BTN.setBackground(Color.black);
        LOGIN_BTN.setForeground(Color.white);
        //
        add(LOGIN_BTN);
        add(txtusername);
        add(txtpassword);
        add(username_DisplayText);
        add(password_Displaytext);
        add(MainTitle);
        getContentPane().setBackground(Color.WHITE);
        //
        LOGIN_BTN.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    String a = txtusername.getText();
                    String b = txtpassword.getText();
                    int count = 0;
                    String Query = "Select * from login_cred where username = ? and password = ?";
                    NewClass n = new NewClass();
                    ps = (PreparedStatement) n.con.prepareStatement(Query);
                    ps.setString(1, a);
                    ps.setString(2, b);
                    rest = ps.executeQuery();
                    if (rest.next()) {
                        JOptionPane.showMessageDialog(null, "Success");
                        new GiantAdminWindowFrame();
                        setVisible(false);
                    }
                    else{
                    JOptionPane.showMessageDialog(null, "Incorrect information, Try Again!");
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        });
        setVisible(true);
    }
    public static void main(String[] args) {
        new CinemaEmployeeAuthentication();
    }
}
