package management.cinema.gui;

import java.awt.Color;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import management.cinema.Dbconnection.NewClass;
import javax.swing.*;
import javax.swing.table.TableModel;

public class Delete_Admins extends JFrame {
    JTable Admin_infos;
    JScrollPane JSpane;
    //
    NewClass n = new NewClass();
    ResultSet rs;
    PreparedStatement ps;
    //
    Delete_Admins() {
        setSize(400,400);
        setLocation(520, 150);
        getContentPane().setBackground(Color.WHITE);
        String Heading_Row[] = {"Username","Password"};
        String Data_Rows[][] = new String[39][10];
        int i = 0;
        int j = 0;
        //
        try {
            ps = (com.mysql.jdbc.PreparedStatement) n.con.prepareStatement("Select * from login_cred");
            rs = ps.executeQuery();
            while (rs.next()) {
                Data_Rows[i][j++] = rs.getString("username");
                Data_Rows[i][j++] = rs.getString("password");
                i++;
                j = 0;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        Admin_infos = new JTable(Data_Rows, Heading_Row) {
            @Override
            public boolean isCellEditable(int data, int column) {
                return false;
            }
        };
        JSpane = new JScrollPane(Admin_infos);
        add(JSpane);
        Admin_infos.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent ae){
                int index = Admin_infos.getSelectedRow();
                TableModel tmodel = Admin_infos.getModel();
                String a = tmodel.getValueAt(index, 0).toString();
                String b = tmodel.getValueAt(index, 1).toString();
                String Query = "DELETE FROM login_cred where username =?";
                try{ 
                    int i= JOptionPane.showConfirmDialog(rootPane, "Are You Sure You Want to Delete The Admin Record from the Database?", "Alert!", JOptionPane.YES_NO_OPTION);
                    if(i==JOptionPane.YES_OPTION){
                        ps=n.con.prepareStatement(Query);
                        ps.setString(1, a);
                        ps.executeUpdate();
                        JOptionPane.showMessageDialog(null, "Record has been Deleted Successfully!\n press 'OK' to Refresh!");
                    }
                }
                catch(Exception e){e.printStackTrace();}
                setVisible(false);
                new Delete_Admins();
            }
        });
        setVisible(true);
    }
    public static void main(String[] args) {
        new Delete_Admins();
    }
}
