package management.cinema.gui;

import com.mysql.jdbc.PreparedStatement;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.util.Date;
import management.cinema.Dbconnection.NewClass;

public class Finance_Collector extends JFrame {
    JTable Customer_infos;
    JButton PrepareReport = new JButton("Prepare Report");
    JScrollPane jsp;
    JPanel Table_panel = new JPanel();
    //
    int totalRev = 0;
    int ticketsintotal = 0;
    ResultSet rs;
    PreparedStatement ps;
    NewClass n = new NewClass();
    Finance_Report F_R = new Finance_Report();

    Finance_Collector() {
         
        setLayout(new BorderLayout()); 
        setTitle("Finance Calculator");
        setLocation(400, 50);
        setSize(500, 480);
        getContentPane().setBackground(Color.WHITE);
        //
        String Heading_Row[] = {"name", "cnic", "debit Card", "Movie Name", "Seat No", "TicketID", "fees", "Date"};
        String Data_Rows[][] = new String[30][10];
        int i = 0;
        int j = 0;
        //
        try {
            ps = (PreparedStatement) n.con.prepareStatement("Select * from book_tickets");
            rs = ps.executeQuery();
            while (rs.next()) {
                ticketsintotal++;
                Data_Rows[i][j++] = rs.getString("name");
                Data_Rows[i][j++] = rs.getString("cnic");
                Data_Rows[i][j++] = rs.getString("debit_card");
                Data_Rows[i][j++] = rs.getString("Movie_name");
                Data_Rows[i][j++] = rs.getString("seat_no");
                Data_Rows[i][j++] = rs.getString("ticket_id");
                Data_Rows[i][j++] = rs.getString("fees_in_dollars");
                Data_Rows[i][j++] = rs.getString("date");
                i++;
                j = 0;
                totalRev = totalRev + Integer.parseInt(rs.getString("fees_in_dollars"));
            }
        }catch (Exception e) {e.printStackTrace();}
        //table object
        Customer_infos = new JTable(Data_Rows, Heading_Row) {
            @Override
            public boolean isCellEditable(int data, int column) {
                return false; //it disables the direct editing when we click on a cell
            }
        };
        //scrollpane to help contain our table
        jsp = new JScrollPane(Customer_infos);
        //Assign Table To the Left
        Table_panel.setBackground(Color.WHITE);
        //scroll pane to contain inside the panel
        Table_panel.add(jsp);
        add(Table_panel, BorderLayout.CENTER);
        add(PrepareReport, BorderLayout.SOUTH);
        //set view of swing components
        PrepareReport.setBackground(Color.BLACK);
        PrepareReport.setForeground(Color.WHITE);
        //Start of event
        PrepareReport.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                Date d = new Date();
                String dateString = d.toString();
                F_R.jta.setText("\n\n\n\n\n\n********************************************************\n                               Revenue Report\n\n\n\n    Total Tickets Booked : " + ticketsintotal + "  \n\n\n    Total Revenue : " + totalRev + "\n\n\n    Date : " + dateString + "\n\n\n\n\n********************************************************");
                F_R.setVisible(true);
            }
        });
        setVisible(true);
    }
    public static void main(String[] args) {
        new Finance_Collector();
    }

}
