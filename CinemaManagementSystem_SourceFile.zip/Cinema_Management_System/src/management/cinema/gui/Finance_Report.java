
package management.cinema.gui;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

//print the finance information
public class Finance_Report extends JFrame{
    public JTextArea jta = new JTextArea();
    private JButton jb = new JButton("Print Data");
    //
    public Finance_Report(){
        setResizable(false);
        setSize(300,600);
        setLocation(500,30);
        jta.setBounds(0,0,250,500);
        jta.setLineWrap(true);      //will word wrap the line
        jta.setWrapStyleWord(true); //word wrap the word that is too long
        add(jta);  
        add(jb,BorderLayout.SOUTH);
        //
        jb.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ae){
                try {
                    jta.print();
                } catch (Exception ex) {System.out.println(ex);}
            }
        });
    }
    public static void main(String[] args) {
        new Finance_Report();
    }
}
