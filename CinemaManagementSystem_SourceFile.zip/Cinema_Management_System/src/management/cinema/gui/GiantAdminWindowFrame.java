package management.cinema.gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.logging.Level;
import java.util.logging.Logger;

//Admin Module Handler
public class GiantAdminWindowFrame extends JFrame {
    private final JMenuBar Menu_Bar = new JMenuBar();
    //
    private JMenu menu1 = new JMenu();
    private JMenu menu2 = new JMenu();
    private JMenu menu3 = new JMenu();
    //
    private JMenuItem item1 = new JMenuItem();
    private JMenuItem item4 = new JMenuItem();
    private JMenuItem item5 = new JMenuItem();
    private JMenuItem item6 = new JMenuItem();
    //
    private JMenuItem item7 = new JMenuItem("Finance calculator");
    private JMenuItem item8 = new JMenuItem("Add More Admins");
    private JMenuItem cust_item = new JMenuItem("Customer History");
    //
    JLabel GiantTxtMain = new JLabel("Admin Module");
    JLabel LowerTextMain = new JLabel("Cinema Management System");
    JLabel infos = new JLabel("Note : Use Menus For Admin Controls");
    //
    private JMenuItem Del_admin = new JMenuItem("Delete Admins");
    private JMenuItem movierecord = new JMenuItem("Show Movie List");
    //
    public GiantAdminWindowFrame() {
        setUndecorated(true);
        setLayout(null);
        setResizable(false);
        setSize(1380, 730);
        setLocation(0, 1);
        setTitle("Book Your Tickets");
        //
        getContentPane().setBackground(Color.LIGHT_GRAY);
        //
        Menu_Bar.setBounds(0, 0, 1380, 35);
        GiantTxtMain.setBounds(300, 100, 1000, 100);
        LowerTextMain.setBounds(300, 200, 1000, 100);
        infos.setBounds(300, 400, 1000, 100);
        //
        menu1.setText("Management");
        menu2.setText("Options");
        menu3.setText("more");
        //
        item1.setText("Manage Movie Records");
        item4.setText("Customer Module");
        item5.setText("About Project");
        item6.setText("Exit");
        item7.setText("Finance Collector");
        //
        Menu_Bar.add(menu1);
        Menu_Bar.add(menu2);
        Menu_Bar.add(menu3);
        //
        menu1.add(cust_item);
        menu1.add(item1);
        menu1.add(item8);
        menu1.add(Del_admin);
        menu2.add(movierecord);
        menu2.add(item4);
        menu2.add(item7);
        menu3.add(item5);
        menu3.add(item6);
        //  
        add(Menu_Bar);
        add(LowerTextMain);
        add(Menu_Bar);
        add(GiantTxtMain);
        add(infos);
        //
        GiantTxtMain.setFont(new Font("Calibri", Font.BOLD, 100));
        LowerTextMain.setFont(new Font("Calibri", Font.BOLD, 65));
        infos.setFont(new Font("Calibri", Font.BOLD, 40));
        //
        setVisible(true);
        //item 1 event start
        item1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                new MovieRecordManagement().setVisible(true);
            }
        });
        //item 6 event start
        item6.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                int i = JOptionPane.showConfirmDialog(null, "Are you Sure you want to Exit?", "Warning!", JOptionPane.YES_NO_OPTION);
                if (i == JOptionPane.YES_OPTION) {
                    setVisible(false);
                    new BookTicket_or_Login().setVisible(true);
                }
            }
        });
        //item 4 event start
        item4.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                int i = JOptionPane.showConfirmDialog(null, "Do you Want To Switch Over to Customer Tab?", "Alert!", JOptionPane.YES_NO_OPTION);
                if (i == JOptionPane.YES_OPTION) {
                    setVisible(false);
                    try {
                        new GiantCustomerWindowFrame().setVisible(true);
                    } catch (Exception ex) {
                        Logger.getLogger(GiantAdminWindowFrame.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            }
        });
        //item 5 event start
        item5.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                new About_Project().setVisible(true);
            }
        });
        //item 7 event start
        item7.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {

                new Finance_Collector().setVisible(true);
            }
        });
        //item 8 event start
        item8.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                new AddmoreAdmins().setVisible(true);
            }
        });
        cust_item.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                new Customer_History().setVisible(true);
            }
        });
        Del_admin.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
            new Delete_Admins();
            }
        });
        movierecord.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ae){
                new MovieRecords();
            }
        });
    }
    public static void main(String[] args) {
        new GiantAdminWindowFrame();
    }

}
