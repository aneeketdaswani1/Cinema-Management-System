/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package management.cinema.gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.URI;
import java.util.logging.Level;
import java.util.logging.Logger;

//Customer Module Handler
public class GiantCustomerWindowFrame extends JFrame{
    private final JMenuBar Menu_Bar= new JMenuBar();
    //
    private JMenu menu1 = new JMenu();
    private JMenu menu2 = new JMenu(); 
    private JMenu menu3 = new JMenu();
    //
    private JMenuItem item1 = new JMenuItem();
    private JMenuItem item2 = new JMenuItem();
    private JMenuItem item3 = new JMenuItem();
    private JMenuItem item4 = new JMenuItem();
    private JMenuItem item5 = new JMenuItem();
    private JMenuItem item6 = new JMenuItem();
    private JMenuItem item7 = new JMenuItem();
    private JMenuItem item8 = new JMenuItem();
    private JMenuItem item9 = new JMenuItem();
    //
    JLabel GiantTxtMain = new JLabel("Customer Module");
    JLabel LowerTextMain = new JLabel("Cinema Management System");
    JLabel infos = new JLabel("Note : Use Menus For Customer Service");
    //
    public GiantCustomerWindowFrame() throws Exception{
        setUndecorated(true);
        setLayout(null);
        setResizable(false);
        setSize(1380,730);
        setLocation(0,1);
        setTitle("Book Your Tickets");
        //
        getContentPane().setBackground(Color.ORANGE);
        //
        Menu_Bar.setBounds(0,0,1380,35);
        GiantTxtMain.setBounds(300,100,1000,100);
        LowerTextMain.setBounds(300,200,1000,100);
        infos.setBounds(300,400,1000,100);
        //
        menu1.add(item1);
        menu1.add(item2);
        menu2.add(item3);
        menu2.add(item4);
        //
        menu3.add(item6);
        menu3.add(item7);
        menu3.add(item9);
        menu3.add(item8);
        //
        Menu_Bar.add(menu1);
        Menu_Bar.add(menu2);
        Menu_Bar.add(menu3);
        //
        menu1.setText("Tickets");
        menu2.setText("Inquiry");
        menu3.setText("More");
        //
        item1.setText("Book Ticket");
        item2.setText("Verify Ticket");
        item3.setText("Weekly Movie list");
        item4.setText("Available Seats");
        //
        item6.setText("About Project");
        item7.setText("Check Movies Online");
        item8.setText("Exit");
        item9.setText("Login");
        //
        GiantTxtMain.setFont(new Font("Calibri",Font.BOLD,100));
        LowerTextMain.setFont(new Font("Calibri",Font.BOLD,65));
        infos.setFont(new Font("Calibri",Font.BOLD,40));
        //
        add(LowerTextMain);
        add(Menu_Bar);
        add(GiantTxtMain);
        add(infos);
        setVisible(true);
        //item 7 event start
        item7.addActionListener(new ActionListener(){
        public void actionPerformed(ActionEvent ae){
            try {
                java.awt.Desktop.getDesktop().browse(URI.create("https://www.google.com/search?sxsrf=ALeKk01mBRyf_jAiCo1n761PHuJQuvPo7g%3A1593293392048&source=hp&ei=ULr3XohnirFQx9eM6AY&q=top+blockbuster+movies+2020&oq=top+&gs_lcp=CgZwc3ktYWIQAxgAMgQIIxAnMgQIIxAnMgQIIxAnMgUIABCRAjICCAAyBQgAELEDMgUIABCxAzIFCAAQsQMyAggAMgIIADoHCCMQ6gIQJzoICAAQsQMQkQI6BQgAEIMBUMAQWNYVYOUiaAFwAHgAgAHvAYgBpweSAQMyLTSYAQCgAQGqAQdnd3Mtd2l6sAEK&sclient=psy-ab"));
            } catch (IOException ex) {
                Logger.getLogger(GiantCustomerWindowFrame.class.getName()).log(Level.SEVERE, null, ex);
            }
        }});
        //item 6 event start
        item6.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ae){
                new About_Project().setVisible(true);
            }
        });
        //item 1 event start
        item1.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ae){
                new IssueAticket().setVisible(true);
            }
        });
        item2.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ae){
                try {
                    new Ticket_Verification().setVisible(true);
                } catch (Exception ex) {
                    Logger.getLogger(GiantCustomerWindowFrame.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
        //item 3 event start
        item3.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ae){
                new Movie_Records_Table().setVisible(true);
            }
        });
        //item 4 event start
        item4.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ae){
                new Seats_Availability().setVisible(true);
            }
        });
        //item 8 event start
        item8.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ae){
                setVisible(false);
                new BookTicket_or_Login().setVisible(true);
            }
        }); 
        //item 9 event start
        item9.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ae){
                int i = JOptionPane.showConfirmDialog(null, "Do you Want to switch to admin Module?", "Alert!", JOptionPane.YES_NO_OPTION);
                if(i==JOptionPane.YES_OPTION){     
                    new CinemaEmployeeAuthentication();
                    setVisible(false);
                }
            }
        });
    }
    public static void main(String[] args) throws Exception{
        new GiantCustomerWindowFrame();
    }
}
