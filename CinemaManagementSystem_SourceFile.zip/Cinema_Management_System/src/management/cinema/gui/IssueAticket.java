package management.cinema.gui;

import com.mysql.jdbc.PreparedStatement;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;
import management.cinema.logic.Booking_TicketsClass;
import java.sql.ResultSet;
import java.util.Date;
import management.cinema.Dbconnection.NewClass;

//book ticket through this
public class IssueAticket extends JFrame {
    Booking_TicketsClass Btc = new Booking_TicketsClass();
    ResultSet rs;
    PreparedStatement ps;
    NewClass n = new NewClass();
    //for generating seat number and ticket id
    Random randticket = new Random();
    //
    IssueAticket() {
        movie_listFill();
        setUndecorated(true);
        setLayout(null);
        setResizable(false);
        setSize(600, 600);
        setLocation(400, 50);
        getContentPane().setBackground(Color.WHITE);
        //
        MainTitle.setBounds(120, 20, 400, 50);
        TxtName.setBounds(300, 120, 150, 20);
        Name_DisplayText.setBounds(100, 107, 100, 25);
        Txtcnic.setBounds(300, 160, 150, 20);
        cnic_DisplayText.setBounds(100, 157, 100, 25);
        TxtDebitcard.setBounds(300, 210, 150, 20);
        DebitCard_displayText.setBounds(100, 207, 100, 25);
        jcb.setBounds(300, 260, 150, 20);
        txtmovieLabel.setBounds(100, 257, 175, 25);
        book_tickets.setBounds(200, 380, 90, 70);
        Cancel_transaction.setBounds(300, 380, 90, 70);
        Txtfooter_info.setBounds(10, 510, 700, 25);
        //
        book_tickets.setBackground(Color.BLACK);
        Cancel_transaction.setBackground(Color.BLACK);
        book_tickets.setForeground(Color.WHITE);
        Cancel_transaction.setForeground(Color.WHITE);
        MainTitle.setFont(new Font("Calibri", Font.BOLD, 50));
        //
        add(TxtName);
        add(Name_DisplayText);
        add(Txtcnic);
        add(cnic_DisplayText);
        add(TxtDebitcard);
        add(DebitCard_displayText);
        add(jcb);
        add(txtmovieLabel);
        add(book_tickets);
        add(Cancel_transaction);
        add(Txtfooter_info);
        add(MainTitle);

        setVisible(true);
        //
        book_tickets.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                try {
                    String nametext = (String) TxtName.getText();
                    int cnictext = Integer.parseInt(Txtcnic.getText());
                    int debitcardtext = Integer.parseInt(TxtDebitcard.getText());
                    int ticket_id_num = randticket.nextInt(9999);
                    int seat_no = randticket.nextInt(100);
                    int price = 15;
                    String movcom = (String) jcb.getSelectedItem();
                    Date d = new Date();
                    String dateDATA = d.toString();
                    //
                    Btc.setName(nametext);
                    Btc.setcnic(cnictext);
                    Btc.setdebitcard(debitcardtext);
                    Btc.setmoviename(movcom);
                    //
                    ps = (PreparedStatement) n.con.prepareStatement("INSERT INTO `book_tickets`(`name`, `cnic`, `debit_card`, `Movie_name`, `seat_no`, `ticket_id`, `fees_in_dollars`,`date`) VALUES (?,?,?,?,?,?,?,?)");
                    ps.setString(1, Btc.getName());
                    ps.setInt(2, Btc.getcnic());
                    ps.setInt(3, Btc.getdebitcard());
                    ps.setString(4, Btc.getmoviename());
                    ps.setInt(5, seat_no);
                    ps.setInt(6, ticket_id_num);
                    ps.setInt(7, price);
                    ps.setString(8, dateDATA);
                    ps.executeUpdate();
                    //
                    JOptionPane.showMessageDialog(null, "Purchase Was Successful!");
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        Cancel_transaction.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                int option = JOptionPane.showConfirmDialog(null, "Are You Sure?", "Warning", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
                if (option == JOptionPane.YES_OPTION) {
                    setVisible(false);
                }
            }
        });
    }
    public static void main(String[] args) {
        new IssueAticket();
    }
    JTextField TxtName = new JTextField();
    JLabel Name_DisplayText = new JLabel("Name");
    JTextField Txtcnic = new JTextField();
    JLabel cnic_DisplayText = new JLabel("Enter CNIC");
    JTextField TxtDebitcard = new JTextField();
    JLabel DebitCard_displayText = new JLabel("Debit Card");
    JComboBox jcb = new JComboBox();
    JLabel txtmovieLabel = new JLabel("Select your Favourite movie");
    //
    JButton book_tickets = new JButton("Purchse");
    JButton Cancel_transaction = new JButton("Cancel");
    JLabel Txtfooter_info = new JLabel("Please note That The IDs and Seats are issued upon successful transaction, view the verify ticket tab");
    JLabel MainTitle = new JLabel("Book Your Tickets");
    public void movie_listFill() { //method for fetching movie names
        try {
            rs = n.stmt.executeQuery("Select * From movie_list");
            while (rs.next()) {
                jcb.addItem(rs.getString("Movie_Name"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}