package management.cinema.gui;

import com.mysql.jdbc.PreparedStatement;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import management.cinema.Dbconnection.NewClass;
import management.cinema.logic.Movie_information;

//Adding movies
public class MovieAdd extends JFrame {
    private JLabel moivenamelab = new JLabel("Movie Name");
    private JLabel durationlab = new JLabel("Duration");
    private JLabel releasedatelab = new JLabel("Release Date");
    private JLabel grossincomelab = new JLabel("Gross Income");
    private JLabel timinglab = new JLabel("Timings");
    //
    private JTextField moviename = new JTextField();
    private JTextField duration = new JTextField();
    private JTextField releasedate = new JTextField();
    private JTextField grossincome = new JTextField();
    private JTextField timing = new JTextField();
    //
    private JButton AddMovieRecordtodb = new JButton();
    //
    private JLabel titletext = new JLabel("Add Movie records");
    //
    Movie_information mi = new Movie_information();
    PreparedStatement ps;
    NewClass n = new NewClass();
    MovieAdd() {
        setResizable(false);
        setTitle("Add Movie Record");
        setLayout(null);
        setSize(900, 700);
        setLocation(250, 30);
        //
        getContentPane().setBackground(Color.ORANGE);
        //
        titletext.setBounds(170, 5, 600, 100);
        moivenamelab.setBounds(280, 130, 100, 25);
        durationlab.setBounds(280, 230, 100, 25);
        releasedatelab.setBounds(280, 330, 100, 25);
        grossincomelab.setBounds(280, 430, 100, 25);
        timinglab.setBounds(280, 530, 100, 25);
        moviename.setBounds(480, 130, 100, 30);
        duration.setBounds(480, 230, 100, 30);
        releasedate.setBounds(480, 330, 100, 30);
        grossincome.setBounds(480, 430, 100, 30);
        timing.setBounds(480, 530, 100, 30);
        AddMovieRecordtodb.setBounds(370, 610, 100, 40);
        //
        titletext.setFont(new Font("Calibri", Font.BOLD, 70));
        AddMovieRecordtodb.setBackground(Color.GRAY);
        AddMovieRecordtodb.setForeground(Color.WHITE);
        AddMovieRecordtodb.setText("Add");
        //
        add(titletext);
        add(moivenamelab);
        add(durationlab);
        add(releasedatelab);
        add(grossincomelab);
        add(timinglab);
        add(moviename);
        add(duration);
        add(releasedate);
        add(grossincome);
        add(timing);
        add(AddMovieRecordtodb);
        setVisible(true);
        //
        AddMovieRecordtodb.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                try {
                    String t1 = moviename.getText();
                    String t2 = duration.getText();
                    String t3 = releasedate.getText();
                    String t4 = grossincome.getText();
                    String t5 = timing.getText();
                    mi.setmoviename(t1);
                    mi.setDuration(t2);
                    mi.setRelease_Date(t3);
                    mi.setGross_income(t4);
                    mi.setTimings(t5);
                    String Query="INSERT INTO `movie_list`(`Movie_Name`, `Duration`, `Release_Date`, `Gross_Income`, `Timings`) VALUES (?,?,?,?,?)";
                    ps = (PreparedStatement) n.con.prepareStatement(Query);
                    ps.setString(1,mi.getmoviename());
                    ps.setString(2,mi.getDuration());
                    ps.setString(3,mi.getRelease_Date());
                    ps.setString(4,mi.getGross_income());
                    ps.setString(5,mi.getTimings());
                    ps.executeUpdate();
                    JOptionPane.showMessageDialog(null, "New Movie Record has been added");
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
    public static void main(String[] args) {
        new MovieAdd();
    }
}
