package management.cinema.gui;

import com.mysql.jdbc.PreparedStatement;
import java.awt.Color;
import java.sql.ResultSet;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import management.cinema.Dbconnection.NewClass;
import javax.swing.*;
import javax.swing.table.TableModel;

public class MovieDelete extends JFrame {
    JTable Movie_List;
    JPanel Panel_Table = new JPanel();
    JScrollPane tablescrollpane;
    //
    ResultSet rs;
    NewClass n = new NewClass();
    PreparedStatement s;
    //
    public MovieDelete() {
        setTitle("Delete a Movie Record");
        setLocation(500, 120);
        setResizable(false);
        setSize(490, 480);
        //
        String Heading_Row[] = {"Movie Name", "Duraion", "Release Date", "Gross Income", "Timings"};
        String Data_Rows[][] = new String[100][8];
        int i = 0;
        int j = 0;
        try {
            rs = n.stmt.executeQuery("Select * from movie_list;");
            while (rs.next()) {
                Data_Rows[i][j++] = rs.getString("Movie_name");
                Data_Rows[i][j++] = rs.getString("Duration");
                Data_Rows[i][j++] = rs.getString("Release_Date");
                Data_Rows[i][j++] = rs.getString("Gross_Income");
                Data_Rows[i][j++] = rs.getString("Timings");
                i++;
                j = 0;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        Movie_List = new JTable(Data_Rows, Heading_Row) { 
            @Override
            public boolean isCellEditable(int data, int column) {
                return false;
            }
        };
        //
        tablescrollpane = new JScrollPane(Movie_List);
        Panel_Table.setBackground(Color.RED);
        Panel_Table.add(tablescrollpane);
        //
        add(Panel_Table);
        Movie_List.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent ea) {
                try {
                    int index = Movie_List.getSelectedRow();
                    TableModel tm = Movie_List.getModel();
                    String a = tm.getValueAt(index, 0).toString();
                    //
                    String Query = "DELETE FROM `movie_list` WHERE Movie_Name =?";
                    //
                    int i = JOptionPane.showConfirmDialog(rootPane, "Are You Sure You Want to Delete the Record", "Warning!", JOptionPane.YES_NO_OPTION);
                    if (i == JOptionPane.YES_OPTION) {
                        s = (PreparedStatement) n.con.prepareStatement(Query);
                        s.setString(1, a);
                        s.executeUpdate();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
                setVisible(false);
                new MovieDelete();
            }
        });
        setVisible(true);
    }
    public static void main(String[] args) {
        new MovieDelete();
    }
}
