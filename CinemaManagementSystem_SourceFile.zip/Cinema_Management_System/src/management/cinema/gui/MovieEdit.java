package management.cinema.gui;

import java.awt.Color;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.*;
import java.sql.ResultSet;
import javax.swing.table.TableModel;
import management.cinema.Dbconnection.NewClass;

public class MovieEdit extends JFrame {
    JTable Movie_List;
    JPanel Panel_Table = new JPanel();
    JScrollPane tablescrollpane;
    //
    ResultSet rs;
    NewClass n = new NewClass();
    //
    public MovieEdit() {
        setTitle("Edit Movie Records");
        setLocation(500, 120);
        setResizable(false);
        setSize(490, 480);
        String Heading_Row[] = {"Movie Name", "Duraion", "Release Date", "Gross Income", "Timings"};
        String Data_Rows[][] = new String[100][8];
        int i = 0;
        int j = 0;
        try {
            rs = n.stmt.executeQuery("Select * from movie_list;");
            while (rs.next()) {
                Data_Rows[i][j++] = rs.getString("Movie_name");
                Data_Rows[i][j++] = rs.getString("Duration");
                Data_Rows[i][j++] = rs.getString("Release_Date");
                Data_Rows[i][j++] = rs.getString("Gross_Income");
                Data_Rows[i][j++] = rs.getString("Timings");
                i++;
                j = 0;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        Movie_List = new JTable(Data_Rows, Heading_Row) { 
            @Override
            public boolean isCellEditable(int data, int column) {
                return false;
            }
        };
        tablescrollpane = new JScrollPane(Movie_List);
        Panel_Table.setBackground(Color.LIGHT_GRAY);
        Panel_Table.add(tablescrollpane);
        //
        add(Panel_Table);
        //
    Movie_List.addMouseListener(new java.awt.event.MouseAdapter() {
        public void mouseClicked(java.awt.event.MouseEvent r){
            int index = Movie_List.getSelectedRow();
                TableModel tm = Movie_List.getModel();
                String a = tm.getValueAt(index, 0).toString();
                String b = tm.getValueAt(index, 1).toString();
                String c = tm.getValueAt(index, 2).toString();
                String d = tm.getValueAt(index, 3).toString();
                String e = tm.getValueAt(index, 4).toString();
                MovieEditTwo j = new MovieEditTwo();
                j.moviename2.setText(a);
                j.duration.setText(b);
                j.releasedate.setText(c);
                j.grossincome.setText(d);
                j.timing.setText(e);
                setVisible(false);
                j.setVisible(true);
            }
        });
        setVisible(true);
    }
    public static void main(String[] args) {
        new MovieEdit();
    }
}
