package management.cinema.gui;

import java.sql.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import management.cinema.Dbconnection.NewClass;
import management.cinema.logic.Movie_information;

public class MovieEditTwo extends JFrame {
    private JLabel moivenamelab = new JLabel("New Movie Name*");
    private JLabel durationlab = new JLabel("Duration*");
    private JLabel releasedatelab = new JLabel("Release Date*");
    private JLabel grossincomelab = new JLabel("Gross Income*");
    private JLabel timinglab = new JLabel("Timings*");
    //
    public JTextField moviename = new JTextField();
    public JTextField duration = new JTextField();
    public JTextField releasedate = new JTextField();
    public JTextField grossincome = new JTextField();
    public JTextField timing = new JTextField();
    //
    private JButton AddMovieRecordtodb = new JButton();
    //
    private JLabel titletext = new JLabel("Edit Movie records");
    private JLabel moivenamelab2 = new JLabel("Current Movie Name*");
    //
    public JTextField moviename2 = new JTextField();
    //
    Movie_information mi = new Movie_information();
    com.mysql.jdbc.PreparedStatement ps;
    NewClass n = new NewClass();
    //
    public MovieEditTwo() {
        setTitle("Edit Movie Records");
        setLayout(null);
        setSize(900, 700);
        setLocation(250, 30);
        //
        getContentPane().setBackground(Color.LIGHT_GRAY);
        //
        titletext.setBounds(180, 5, 600, 100);
        moivenamelab.setBounds(280, 170, 110, 25);
        durationlab.setBounds(280, 250, 100, 25);
        releasedatelab.setBounds(280, 350, 100, 25);
        grossincomelab.setBounds(280, 450, 100, 25);
        timinglab.setBounds(280, 550, 100, 25);
        moviename.setBounds(480, 170, 100, 30);
        duration.setBounds(480, 250, 100, 30);
        releasedate.setBounds(480, 350, 100, 30);
        grossincome.setBounds(480, 450, 100, 30);
        timing.setBounds(480, 550, 100, 30);
        AddMovieRecordtodb.setBounds(370, 610, 100, 40);
        moivenamelab2.setBounds(280, 110, 120, 25);
        moviename2.setBounds(480, 110, 100, 30);
        titletext.setFont(new Font("Calibri", Font.BOLD, 70));
        AddMovieRecordtodb.setBackground(Color.GRAY);
        AddMovieRecordtodb.setForeground(Color.WHITE);
        AddMovieRecordtodb.setText("Edit");
        //
        add(titletext);
        add(moivenamelab);
        add(durationlab);
        add(releasedatelab);
        add(grossincomelab);
        add(timinglab);
        add(moviename);
        add(duration);
        add(releasedate);
        add(grossincome);
        add(timing);
        add(AddMovieRecordtodb);
        add(moivenamelab2);
        add(moviename2);
        //
        AddMovieRecordtodb.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    String t1 = moviename.getText();
                    String t2 = duration.getText();
                    String t3 = releasedate.getText();
                    String t4 = grossincome.getText();
                    String t5 = timing.getText();
                    String t6 = moviename2.getText();
                    //
                    mi.setmoviename(t1);
                    mi.setDuration(t2);
                    mi.setRelease_Date(t3);
                    mi.setGross_income(t4);
                    mi.setTimings(t5);
                    //
                    String Query = "UPDATE `movie_list` SET Movie_Name=?,Duration=?,Release_Date=?,Gross_Income=?,Timings=? WHERE Movie_Name=?";
                    //
                    ps = (com.mysql.jdbc.PreparedStatement) n.con.prepareStatement(Query);
                    ps.setString(1, mi.getmoviename());
                    ps.setString(2, mi.getDuration());
                    ps.setString(3, mi.getRelease_Date());
                    ps.setString(4, mi.getGross_income());
                    ps.setString(5, mi.getTimings());
                    ps.setString(6, t6);
                    ps.executeUpdate();
                    //
                    JOptionPane.showMessageDialog(null, "New Movie Record has been Updated Successfully!");
                    setVisible(false);
                    //
                    new MovieEdit();
                } catch (Exception ex) {ex.printStackTrace(); }
            }
        });
    }
    public static void main(String[] args) {
        new MovieEditTwo();
    }
}