/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package management.cinema.gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

//Manage Movies using this class
public class MovieRecordManagement extends JFrame {
    JLabel lab1 = new JLabel("Add or Manage Movie Records");
    JLabel lab2 = new JLabel("Use Menus For Record Management");
    //
    JMenuBar jmb = new JMenuBar();
    //
    JMenu jm1 = new JMenu();
    JMenu jm2 = new JMenu();
    //
    JMenuItem jmi1 = new JMenuItem();
    JMenuItem jmi2 = new JMenuItem();
    JMenuItem jmi3 = new JMenuItem();
    JMenuItem jmi4 = new JMenuItem();
    JMenuItem jmi5 = new JMenuItem();
    //
    MovieRecordManagement() {
        setLayout(null);
        setResizable(false);
        setSize(1000, 600);
        setLocation(200, 30);
        getContentPane().setBackground(Color.ORANGE);
        //
        lab1.setFont(new Font("Calibri", Font.BOLD, 70));
        lab2.setFont(new Font("Calibri", Font.BOLD, 45));
        //
        lab1.setBounds(20, 150, 1000, 120);
        lab2.setBounds(20, 300, 1000, 100);
        jmb.setBounds(0, 0, 1000, 30);
        //
        jmb.add(jm1);
        jmb.add(jm2);
        //
        jm1.add(jmi1);
        jm1.add(jmi2);
        jm1.add(jmi3);
        jm2.add(jmi5);
        //
        add(jmb);
        add(lab1);
        add(lab2);
        //
        jm1.setText("Options");
        jm2.setText("more");
        jmi1.setText("Add");
        jmi2.setText("Edit");
        jmi3.setText("Delete");
        jmi5.setText("Exit");
        //
        setVisible(true);
        //
        jmi1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ex) {
                new MovieAdd().setVisible(true);
            }
        });
        //Start of Event of Jmenuitem2
        jmi2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                new MovieEdit();
            }
        });
        //Start of Event of Jmenuitem3
        jmi3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ex) {
               new MovieDelete();
            }
        });
        //start of Event of Jmenuitem5
        jmi5.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ex) {
                setVisible(false);
            }
        });
    }
    public static void main(String[] args) {
        new MovieRecordManagement();
    }
}
