package management.cinema.gui;

import javax.swing.*;
import java.awt.*;
import java.sql.*;
import management.cinema.Dbconnection.NewClass;

public class MovieRecords extends JFrame{
ResultSet resultset;
NewClass newclass = new NewClass();
    public MovieRecords() {
        setResizable(false);
        setLocation(200, 120);
        setSize(1000, 480);
        //
        String Heading_Row[] = {"Movie Name", "Duraion", "Release Date", "Gross Income", "Timings"};
        String Data_Rows[][] = new String[100][8];
        int i = 0;
        int j = 0;
        try{
            resultset= newclass.stmt.executeQuery("Select * from movie_list;");
            while (resultset.next()) {
                Data_Rows[i][j++] =resultset.getString("Movie_name");
                Data_Rows[i][j++] = resultset.getString("Duration");
                Data_Rows[i][j++] = resultset.getString("Release_Date");
                Data_Rows[i][j++] = resultset.getString("Gross_Income");
                Data_Rows[i][j++] = resultset.getString("Timings");
                i++;
                j=0;
            }       
        } catch(Exception e){e.printStackTrace();}
        jtable = new JTable(Data_Rows, Heading_Row) { 
            @Override
            public boolean isCellEditable(int data, int column) {
                return false;
            }
        };
        jscrollpane = new JScrollPane(jtable);
        add(jscrollpane);
        setVisible(true);
    }
    JTable jtable;
    JScrollPane jscrollpane;
    public static void main(String[] args) {
        new MovieRecords();
    }
}