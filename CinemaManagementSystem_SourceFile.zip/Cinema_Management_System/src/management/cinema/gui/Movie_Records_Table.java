package management.cinema.gui;

import javax.swing.*;
import java.awt.*;
import java.sql.ResultSet;
import management.cinema.Dbconnection.NewClass;

//weekly Movie List Tab
public class Movie_Records_Table extends JFrame {
    JTable Movie_List;
    JScrollPane tablescrollpane;
    JPanel Panel_Table = new JPanel();
    //
    ResultSet rs;
    NewClass n = new NewClass();
    //
    public Movie_Records_Table() {
        setResizable(false);
        setTitle("Weekly Movie List");
        setLocation(500, 120);
        setSize(490, 480);
        //
        String Heading_Row[] = {"Movie Name", "Duraion", "Release Date", "Gross Income", "Timings"};
        String Data_Rows[][] = new String[100][8];
        int i = 0;
        int j = 0;
        try{
        rs= n.stmt.executeQuery("Select * from movie_list;");
            while (rs.next()) {
                Data_Rows[i][j++] =rs.getString("Movie_name");
                Data_Rows[i][j++] = rs.getString("Duration");
                Data_Rows[i][j++] = rs.getString("Release_Date");
                Data_Rows[i][j++] = rs.getString("Gross_Income");
                Data_Rows[i][j++] = rs.getString("Timings");
                i++;
                j=0;
            }
        } catch(Exception e){e.printStackTrace();}
            Movie_List = new JTable(Data_Rows, Heading_Row) { 
                @Override
                public boolean isCellEditable(int data, int column) {
                    return false;
            }
        };
        tablescrollpane = new JScrollPane(Movie_List);
        Panel_Table.setBackground(Color.ORANGE);
        Panel_Table.add(tablescrollpane);
        //
        add(Panel_Table);
        //
        setVisible(true);
    }
    public static void main(String[] args) {
        new Movie_Records_Table();
    } 
}