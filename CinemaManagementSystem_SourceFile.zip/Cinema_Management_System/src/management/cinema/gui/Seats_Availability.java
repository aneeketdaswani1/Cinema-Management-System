package management.cinema.gui;

import com.mysql.jdbc.PreparedStatement;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import management.cinema.Dbconnection.NewClass;

//checks for seat availability in cinema overall
public class Seats_Availability extends JFrame {
    JButton Search_Seats = new JButton("Search");
    JLabel Footer_text = new JLabel("");
    JLabel Title_Text = new JLabel("Search for seats");
    JLabel header_text = new JLabel("Select Movie");
    JComboBox jcb = new JComboBox();
    //
    NewClass n = new NewClass();
    //
    ResultSet rs;
    PreparedStatement ps;
    //
    int countervaar = 0;
    public Seats_Availability() {
        movie_listFill(); 
        //
        setLayout(null);
        setTitle("Seat Availability");
        setResizable(false);
        setSize(600, 350);
        setLocation(400, 100);
        getContentPane().setBackground(Color.LIGHT_GRAY);
        //
        Title_Text.setBounds(135, 12, 500, 60);
        Search_Seats.setBounds(240, 190, 90, 70);
        header_text.setBounds(140, 115, 250, 50);
        Footer_text.setBounds(150, 280, 320, 25);
        jcb.setBounds(300, 120, 150, 30);
        //
        Search_Seats.setBackground(Color.BLACK);
        Search_Seats.setForeground(Color.WHITE);
        header_text.setFont(new Font("Calibri", Font.BOLD, 20));
        Title_Text.setFont(new Font("Calibri", Font.BOLD, 50));
        //
        add(Title_Text);
        add(Search_Seats);
        add(Footer_text);
        add(header_text);
        add(jcb);
        // 
        Search_Seats.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                total_seats(); 
                Footer_text.setText("Total Seats Available Overall left in cinema : " + (100 - countervaar));
            }
        });
        setVisible(true);
        System.out.println(countervaar);
    }
    public static void main(String[] args) {
        new Seats_Availability();
    }


    public void movie_listFill() { //method for fetching movie names
        try {
            rs = n.stmt.executeQuery("Select * From movie_list");
            while (rs.next()) {
                jcb.addItem(rs.getString("Movie_Name"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void total_seats() { //method for counting total number of seats left in cinema
        try {
            countervaar=0;
            String a = (String) jcb.getSelectedItem();
            ps = (PreparedStatement) n.con.prepareStatement("SELECT * FROM `book_tickets` WHERE movie_name =?;");
            ps.setString(1, a);
            rs=ps.executeQuery();
            while(rs.next()){
                this.countervaar++;
            }
        } catch (Exception e) {e.printStackTrace();}
    }
}