package management.cinema.gui;

import com.mysql.jdbc.PreparedStatement;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import management.cinema.Dbconnection.NewClass;
import java.sql.*;

//verify ticket through this tab
public class Ticket_Verification extends JFrame {
    JLabel cnic_display = new JLabel("CNIC");
    JTextField txtcnic = new JTextField();
    JButton check_btn = new JButton("Check");
    JLabel Maintext = new JLabel("Verify your Ticket");
    //
    NewClass i = new NewClass();
    //
    Ticket_info_tab n = new Ticket_info_tab();
    PreparedStatement ps;
    ResultSet rs;
    //
    public Ticket_Verification() throws Exception {
        
        setLayout(null);
        setResizable(false);
        setTitle("Ticket Verification");
        setLocation(400, 100);
        setSize(500, 600);
        //
        getContentPane().setBackground(Color.LIGHT_GRAY);
        //
        Maintext.setBounds(70, 50, 500, 60);
        Maintext.setFont(new Font("Calibri", Font.BOLD, 50) {});
        //
        cnic_display.setBounds(100, 200, 50, 25);
        txtcnic.setBounds(200, 200, 200, 30);
        //
        check_btn.setBounds(200, 350, 90, 70);
        check_btn.setBackground(Color.BLACK);
        check_btn.setForeground(Color.WHITE);
        //
        add(Maintext);
        add(cnic_display);
        add(txtcnic);
        add(check_btn);
        //
        check_btn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                check();
            }
        });
        setVisible(true);
    }
    public void check() {
        try {
            String a = txtcnic.getText();
            String name; int cnic; int Debitcard; String moviename; int seatno; int ticketid; int fees; String date;
            ps = (PreparedStatement) i.con.prepareStatement("SELECT * FROM `book_tickets` WHERE cnic=?");
            ps.setString(1, a);
            rs=ps.executeQuery();
            while(rs.next()){
                name=rs.getString(1);
                cnic=rs.getInt(2);
                Debitcard=rs.getInt(3);
                moviename=rs.getString(4);
                seatno=rs.getInt(5);
                ticketid=rs.getInt(6);
                fees=rs.getInt(7);
                date=rs.getString(8);
                n.jta.setText("\n\n********************************************************\n                               Your Ticket Info\n\n\n\n    Name : "+name+"  \n\n\n    CNIC : "+cnic+"\n\n\n    Debit Card No. : "+Debitcard+"\n\n\n    Movie Name :"+moviename+"\n\n\n    Seat No. : "+seatno+"\n\n\n   Ticket ID : "+ticketid+"\n\n\n   Fees Payed : $"+fees+"\n\n\n   Date : "+date+"\n\n\n\n********************************************************");
                n.setVisible(true);
            }
        } catch (Exception e) {e.printStackTrace();}
    }
    public static void main(String[] args) throws Exception {
        new Ticket_Verification();
    }
}
