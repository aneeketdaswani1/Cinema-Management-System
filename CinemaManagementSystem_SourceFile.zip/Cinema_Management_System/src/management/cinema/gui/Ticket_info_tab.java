package management.cinema.gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.print.PrinterException;

public class Ticket_info_tab extends JFrame{   
    JTextArea jta = new JTextArea();
    JButton jb = new JButton("Print");
    //
    public Ticket_info_tab(){
        setResizable(false);
        setSize(300,600);
        setLocation(300,30);
        jta.setBounds(0,0,300,500);
        jta.setWrapStyleWord(true);
        jta.setLineWrap(true);
        jb.setBackground(Color.BLACK);
        jb.setForeground(Color.WHITE);
        add(jta);  
        add(jb,BorderLayout.SOUTH);
        //
        jb.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ae){
                try {
                    jta.print();
                } catch (PrinterException ex) {
                    ex.printStackTrace();
                }
            }
        });
    }
    public static void main(String[] args) {
        new Ticket_info_tab();
    }
}
