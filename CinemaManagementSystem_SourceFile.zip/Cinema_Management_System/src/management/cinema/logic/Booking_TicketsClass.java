package management.cinema.logic;

public class Booking_TicketsClass {
    //
    private String Name;
    private int cnic;
    private int debitcard;
    private String movie;
    //
    public void setName(String Name){
        this.Name=Name;
    }
    public String getName(){
       return this.Name;
    }
    public void setcnic(int cnic){
        this.cnic=cnic;
    }
    public int getcnic(){
        return this.cnic; 
    }
    public void setdebitcard(int debitcard){
        this.debitcard=debitcard;
    }
    public int getdebitcard(){
        return this.debitcard;
    }
    public void setmoviename(String movie){
        this.movie=movie;
    }
    public String getmoviename(){
        return this.movie;
    }
}

