
package management.cinema.logic;


public class Movie_information {
    private String Movie_Name;
    private String Duration;
    private String Release_Date;
    private String Gross_income;
    private String Timings;
    //
    public void setmoviename(String Movie_Name){
        this.Movie_Name=Movie_Name;
    }
    public String getmoviename(){
    return this.  Movie_Name;  
    }

    public void setDuration(String Duration){
        this.Duration=Duration;
    }
    public String getDuration(){
      return this.Duration;
    }
    public void setRelease_Date(String Release_Date){
     this.Release_Date=Release_Date;   
    }
    public String getRelease_Date(){
        return this.Release_Date;
    }
    public void setGross_income(String Gross_income){
        this.Gross_income=Gross_income;
    }
    public String getGross_income(){
        return this.Gross_income;
    }
    public void setTimings(String Timings){
        this.Timings=Timings;
    }
    public String getTimings(){
        return this.Timings;
    }
}
