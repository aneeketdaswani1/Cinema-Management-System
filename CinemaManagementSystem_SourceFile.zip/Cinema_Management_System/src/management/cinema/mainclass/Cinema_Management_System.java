/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package management.cinema.mainclass;
import management.cinema.gui.BookTicket_or_Login;
import javax.swing.*;
//
public class Cinema_Management_System {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new BookTicket_or_Login();
            }
        });
        //BookTicket_or_Login s = new BookTicket_or_Login();
    }
}
